Sql
CREATE TABLE weather_data (
city_name VARCHAR(255) PRIMARY KEY,
    temperature FLOAT,
    humidity FLOAT,
weather_description VARCHAR(255)
);
