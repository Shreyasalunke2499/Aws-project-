Bash
# Create a new Flask application
Mkdir weather_app
Cd weather_app

# Set up a virtual environment (optional but recommended)
Python3 -m venvvenv
Source venv/bin/activate

# Install Flask and MySQL connector
Pip install Flask mysql-connector-python
