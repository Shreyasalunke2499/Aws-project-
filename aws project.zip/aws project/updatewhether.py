Python 
From flask import Flask, request, jsonify
From mysql.connector import connect, Error

App = Flask(__name__)

# Define a helper function to create a MySQL connection
Def create_db_connection():
    Try:
        Conn = connect(
            Host=’<your-rds-endpoint>’,
            User=’<your-db-username>’,
            Password=’<your-db-password>’,
            Database=’<your-db-name>’
        )
        Return conn
    Except Error as e:
        Print(f”Error: {e}”)
        Return None

# Route for searching weather data by city name
@app.route(‘/weather’, methods=[‘GET’])
Def get_weather_by_city():
City_name = request.args.get(‘city_name’)
    Conn = create_db_connection()
    If conn:
        Cursor = conn.cursor()
Cursor.execute(f”SELECT * FROM weather_data WHERE city_name = ‘{city_name}’”)
        Row = cursor.fetchone()
        If row:
Weather_data = {
                ‘city_name’: row[0],
                ‘temperature’: row[1],
                ‘humidity’: row[2],
                ‘weather_description’: row[3]
            }
            Return jsonify(weather_data), 200
        Else:
            Return jsonify({‘error’: ‘City not found’}), 404
    Else:
        Return jsonify({‘error’: ‘Failed to connect to the database’}), 500

# Route for adding new weather data
@app.route(‘/weather’, methods=[‘POST’])
Def add_weather():
City_name = request.form.get(‘city_name’)
    Temperature = float(request.form.get(‘temperature’))
    Humidity = float(request.form.get(‘humidity’))
Weather_description = request.form.get(‘weather_description’)
    Conn = create_db_connection()
    If conn:
        Cursor = conn.cursor()
Cursor.execute(
            F”INSERT INTO weather_data (city_name, temperature, humidity, weather_description) “
            F”VALUES (‘{city_name}’, {temperature}, {humidity}, ‘{weather_description}’)”
        )
Conn.commit()
Cursor.close()
Conn.close()
        Return jsonify({‘message’: ‘Weather data added successfully’}), 201
    Else:
        Return jsonify({‘error’: ‘Failed to connect to the database’}), 500

# Route for updating weather data
@app.route(‘/weather’, methods=[‘PUT’])
Def update_weather():
City_name = request.form.get(‘city_name’)
    Temperature = float(request.form.get(‘temperature’))
    Humidity = float(request.form.get(‘humidity

